# Rainfall Data Analyzer

Python-based Rainfall Data Analysis Project

A command-line tool that reads monthly rainfall data from a CSV file and analyzes it using **NumPy**, **Pandas** and **Matplotlib**.

**Student:** Yash Chandra  
**Roll No:** RU-26-01217  **Section:** 1D

## Features

- Statistics: total, mean, standard deviation, wettest and driest month
- Heavy rainfall months (above 200 mm)
- Comparison of every month with the average, with a bar chart
- Rainfall trend line chart
- Invalid rows (missing, non-numeric, negative) are skipped with a message
- Handles missing file and empty or fully invalid data

## Project Structure

```
├── Codebase/
│   └── rainfall_analyzer.py
├── testcases/
│   ├── tc01_normal.csv  (+ expected output)
│   ├── tc02_invalid_rows.csv
│   ├── tc03_no_header.csv
│   ├── tc04_empty.csv
│   ├── tc05_no_heavy.csv
│   ├── tc06_all_invalid.csv
│   └── tc07_file_not_found (expected output only)
├── screenshots/
├── requirements.txt
├── README.md
├── LICENSE
└── .gitignore
```

## Installation

```bash
pip install -r requirements.txt
```

## Usage

```bash
cd Codebase
python rainfall_analyzer.py ../testcases/tc01_normal.csv
```

If no file name is given, `rain.csv` is used.

Menu:

```
1. Statistics
2. Heavy rainfall months
3. Compare with average and plot
4. Trend line chart
5. Exit
```

## CSV Format

The header row is optional.

```csv
Month,Rainfall_mm
Jan,10
Feb,5
```

## Test Cases

See the `testcases/` folder. Each `*_expected_output.txt` file is the output of the program for the matching CSV, using menu inputs `1, 2, 3, 4, 9, 5`.

## Screenshots

| Bar chart | Trend chart |
|-----------|-------------|
| ![bar](screenshots/bar_chart.png) | ![trend](screenshots/trend_chart.png) |

## License

MIT License. See [LICENSE](LICENSE).

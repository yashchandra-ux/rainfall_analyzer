# Test Cases

| File | Scenario | Expected result |
|------|----------|-----------------|
| tc01_normal.csv | Valid 12-month data with header | 12 valid rows, heavy months Jul, Aug, Sep |
| tc02_invalid_rows.csv | Text, negative and missing values | Rows 2, 3, 4 skipped, 3 valid rows |
| tc03_no_header.csv | No header row | 4 valid rows, heavy month Mar |
| tc04_empty.csv | Empty file | "Valid rows: 0" then "No valid data to analyse." |
| tc05_no_heavy.csv | All months below 200 mm | "No month above 200 mm" |
| tc06_all_invalid.csv | Every row invalid | All rows skipped, no data to analyse |
| tc07_file_not_found | File does not exist | "File '...' not found." |

Menu inputs used for tc01, tc02, tc03, tc05: `1, 2, 3, 4, 9, 5` (9 checks "Invalid option").
